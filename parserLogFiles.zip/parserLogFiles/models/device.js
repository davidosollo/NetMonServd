const mongoose = require('mongoose');

const DeviceSchema = mongoose.Schema({
    macsender: {type: String, index: true},
    ipsender: {type: String},
    macreceiver: {type: String},
    ipreceiver: {type: String},
    packagecount: {type: Number},
    bytenumber: {type: Number},
    firsttime: {type: String},
    lasttime: {type: String}
});

const Device = module.exports = mongoose.model('Device', DeviceSchema);

module.exports.addDevice = (newDevice, callback) =>{
    newDevice.save(callback);
}