const express = require('express');
const router = express.Router();
const fs = require('fs');
const config = require('../config/config');

//Get home page.
router.get('/', (reg,res) => {
    res.render('index');
});

module.exports = router;