const express = require('express');
const router = express.Router();

const fs = require('fs');
const config = require('../config/config');


router.get('/upload_log/:date', (req, res) => {
    var filelog = ''; 
    var act = req.params.date;
    if(req.params.date != 'current'){
        filelog = config.logfilepath + config.logfilename + '.log';
    }else{
        filelog = config.logfilepath + config.logfilename + '.log';
    }
    var devices = readFile(filelog);
    var devicecont = parseDevice(devices);
    var fileNames = loadLogsName();

    res.render('uploadlog', {
        datafile: devices,
        macs: devicecont[0],
        bytes: devicecont[1],
        pkgs: devicecont[2],
        files: fileNames,
        actlog: act
     });
});

function readFile(fileName){
    var device = {
        macsender : '',
        ipsender: '',
        macreceiver: '',
        ipreceiver: '',
        packagecount: 0,
        bytenumber: 0,
        firsttime: '',
        lasttime: ''
    }
    var devices = [];
    fs.readFileSync(fileName, 'utf-8').split(/\r?\n/).forEach((line) => {
        if(line != '-------------------------------------------'){
            const div = line.indexOf(':');
            var info = [line.substring(0, div), line.substring(div+1).trim()];
            switch(info[0]){
                case 'Mac Sender':
                    device.macsender = info[1];
                    break;
                case 'IP Sender':
                    device.ipsender = info[1];
                    break;
                case 'Mac Receiver':
                    device.macreceiver = info[1];
                    break;
                case 'IP Receiver':
                    device.ipreceiver = info[1];
                    break;
                case 'Package Count':
                    device.packagecount = info[1];
                    break;
                case 'Bytes Number':
                    device.bytenumber = info[1];
                    break;
                case 'First Time':
                    device.firsttime = info[1];
                    break;
                case 'Last Time':
                    device.lasttime = info[1];
                    break;
            }
        }else{
            device = {
                macsender: '',
                ipsender: '',
                macreceiver: '',
                ipreceiver: '',
                packagecount: 0,
                bytenumber: 0,
                firsttime: '',
                lasttime: ''
            }
            devices.push(device);
        }
    });
    return devices;
}

function parseDevice (devices){
    var macsenders = new Set();
    var bytescont = [];
    var macs = [];
    var pkgcont = [];
    
    for(i = 0; i < devices.length; i++){
        macsenders.add(devices[i].macsender);
    }
    var getEntities = macsenders.entries(); 
    for(i = 0; i < macsenders.size; i++){
        var bytes = 0;
        var packages = 0;
        
        var item = getEntities.next().value;
        for(d = 0; d < devices.length; d++){
            if(item[0] === devices[d].macsender){
                bytes = bytes + parseInt(devices[d].bytenumber);
                packages = packages + parseInt(devices[d].packagecount);
            }
        }
        macs.push('\'' + item[0] + '\'');
        bytescont.push(bytes);
        pkgcont.push(packages);
    }
    return [macs, bytescont, pkgcont];
}

function loadLogsName(){
    var fileNames = [];
    fs.readdirSync(config.logfilepath).forEach(function(file) {
        var pref = file.split('.')[0].substr(config.logfilename.length)
        if(pref === ''){
            fileNames.push('Current');
        }else{
            fileNames.push(pref)
        }
    });
    return fileNames;
}
module.exports = router;