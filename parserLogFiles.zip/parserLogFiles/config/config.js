module.exports = {
    database: 'mongodb://127.0.0.0:50000/scanlog',
    logfilepath: './logsfolder/',
    logfilename: 'netMonReport'
}