const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const bodyParse = require('body-parser');
const config = require('./config/config');

const index = require("./routes/index");
const device = require("./routes/device");

mongoose.connect(config.database).then(() => {
    console.log("Connected to Database");
    }).catch((err) => {
        console.log("Not Connected to Database ERROR! ", err);
    });
    
let db = mongoose.connection;

const app = express();

//Load View Engine
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

//Body Parser Middleware
app.use(bodyParse.urlencoded({ extended: false}));
// parse application json
app.use(bodyParse.json());

//Set Public Folder
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', index);
app.use('/devices', device);

//PORT
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Listening on port ${port}`));